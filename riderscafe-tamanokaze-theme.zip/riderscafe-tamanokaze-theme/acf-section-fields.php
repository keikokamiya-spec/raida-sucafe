<?php
/**
 * Optional ACF helper placeholders.
 *
 * The theme does not require ACF to render. If ACF is active, template code can
 * safely call fields by wrapping get_field() with function_exists('get_field').
 */

if (!defined('ABSPATH')) {
  exit;
}
